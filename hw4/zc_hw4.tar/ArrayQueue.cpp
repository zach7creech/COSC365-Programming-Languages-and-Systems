#include "Queue.h"
#include <iostream>

using namespace std;

void ArrayQueue::add(int value)
{
    q.push_back(value);
}

int ArrayQueue::remove()
{
    if(!isEmpty())
    {
        int val = q.front();
        q.pop_front();
        return val;
    }
    else
    {
        cerr << "Error: Queue is empty\n";
        exit(1);
    }
}

bool ArrayQueue::isEmpty()
{
    if(q.size() == 0)
        return true;
    else
        return false;
}
