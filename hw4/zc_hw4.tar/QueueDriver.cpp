#include "Queue.h"
#include <iostream>

using namespace std;

int main()
{
    Queue *q = new ArrayQueue;

    q->add(3);
    q->add(10);
    q->add(5);

    cout << q->remove() << '\n' << q->remove() << '\n';

    q->add(6);
    q->add(9);
    q->add(12);

    while(!q->isEmpty())
    {
        cout << q->remove() << '\n';
    }

    delete q;

    return 0;
}
