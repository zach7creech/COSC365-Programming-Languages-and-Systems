#include <list>

using namespace std;

class Queue
{
    public:
        virtual void add(int value) = 0;
        virtual int remove() = 0;
        virtual bool isEmpty() = 0;
};

class ArrayQueue : public Queue
{
    private:
        list<int> q;
    public:
        void add(int value);
        int remove();
        bool isEmpty();
};
